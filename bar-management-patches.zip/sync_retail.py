#!/usr/bin/env python3
"""
CLI синхронизация Retail API СБИС
Работает с существующей структурой проекта (models.py, sbis_api.py в корне)

Использование:
    python sync_retail.py --sales --days 365          # Продажи за год
    python sync_retail.py --balances                   # Остатки
    python sync_retail.py --nomenclature               # Номенклатура
    python sync_retail.py --all --days 365             # Всё за год
    python sync_retail.py --stats                      # Статистика
"""

import os
import sys
import argparse
import logging
import json
from datetime import datetime, timedelta

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler('sync_retail.log', encoding='utf-8')
    ]
)
logger = logging.getLogger(__name__)

# Импорты из существующего проекта
try:
    from config import Config
    from models import db, StockBalance, SaleRecord, DailySalesSummary
    from sbis_api import SbisAPI
    from app import app as flask_app  # Импортируем Flask приложение
except ImportError as e:
    logger.error("Не удалось импортировать модули проекта: %s", e)
    logger.error("Убедитесь, что скрипт запущен из корня проекта")
    sys.exit(1)

# Создаём контекст приложения
app_context = flask_app.app_context()
app_context.push()


class RetailSync:
    """Синхронизация Retail API"""

    def __init__(self):
        self.sbis = SbisAPI(
            token=Config.SBIS_TOKEN,
            client_id=Config.SBIS_CLIENT_ID,
            app_secret=Config.SBIS_APP_SECRET,
            secret_key=Config.SBIS_SECRET_KEY
        )

        self.point_id = Config.SBIS_POINT_ID
        self.warehouse_id = Config.SBIS_WAREHOUSE_ID
        self.company_id = Config.SBIS_COMPANY_ID
        self.price_list_id = Config.SBIS_PRICE_LIST_ID

        # Парсим point_id
        try:
            self.point_id = int(self.point_id) if self.point_id and self.point_id.strip() and self.point_id.strip().lower() not in ('', 'your-point-id', 'none', 'null') else None
        except (ValueError, AttributeError):
            self.point_id = None

        if not self.point_id:
            logger.error("SBIS_POINT_ID не настроен! Добавьте в .env реальный ID точки продаж.")
            logger.error("Найти можно в ЛК СБИС → Розница → Точки продаж")
            sys.exit(1)

        # Парсим warehouse_id (опционально)
        try:
            self.warehouse_id = int(self.warehouse_id) if self.warehouse_id and self.warehouse_id.strip() and self.warehouse_id.strip().lower() not in ('', 'your-warehouse-id', 'none', 'null') else None
        except (ValueError, AttributeError):
            self.warehouse_id = None

        # Парсим company_id (опционально)
        try:
            self.company_id = int(self.company_id) if self.company_id and self.company_id.strip() and self.company_id.strip().lower() not in ('', 'your-company-id', 'none', 'null') else None
        except (ValueError, AttributeError):
            self.company_id = None

        # Парсим price_list_id (опционально)
        try:
            self.price_list_id = int(self.price_list_id) if self.price_list_id and self.price_list_id.strip() and self.price_list_id.strip().lower() not in ('', 'your-price-list-id', 'none', 'null') else None
        except (ValueError, AttributeError):
            self.price_list_id = None

    # ==================== ПРОДАЖИ ====================

    def sync_sales(self, days=365):
        """Синхронизация продаж за период"""
        logger.info("=" * 60)
        logger.info("СИНХРОНИЗАЦИЯ ПРОДАЖ за %d дней", days)
        logger.info("Точка: %s", self.point_id)
        logger.info("=" * 60)

        date_to = datetime.now()
        date_from = date_to - timedelta(days=days)

        total_imported = 0
        total_updated = 0
        current = date_from

        while current < date_to:
            month_end = min(
                (current.replace(day=1) + timedelta(days=32)).replace(day=1) - timedelta(days=1),
                date_to
            )

            logger.info("Месяц: %s → %s", current.strftime('%Y-%m-%d'), month_end.strftime('%Y-%m-%d'))

            month_imported = 0
            month_updated = 0
            page = 0

            while True:
                result = self.sbis.get_sales(
                    point_id=self.point_id,
                    date_from=current,
                    date_to=month_end,
                    page=page,
                    page_size=100
                )

                if not result:
                    break

                orders = result.get('orders', []) if isinstance(result, dict) else []
                if not orders:
                    break

                for order_data in orders:
                    is_new = self._save_sale(order_data)
                    if is_new:
                        month_imported += 1
                    else:
                        month_updated += 1

                total = result.get('total', 0) if isinstance(result, dict) else len(orders)
                if len(orders) < 100 or (month_imported + month_updated) >= total:
                    break

                page += 1
                import time
                time.sleep(0.2)

            logger.info("  Загружено: %d новых, %d обновлено", month_imported, month_updated)
            total_imported += month_imported
            total_updated += month_updated
            current = month_end + timedelta(days=1)

        logger.info("=" * 60)
        logger.info("ИТОГО: %d новых, %d обновлено", total_imported, total_updated)
        logger.info("=" * 60)

        # Пересчёт дневных агрегатов
        self._recalculate_daily_sales()
        return total_imported

    def _save_sale(self, order_data):
        """Сохраняет/обновляет один заказ. Возвращает True если новый."""
        order_id = str(order_data.get('id', ''))
        if not order_id:
            return False

        sale = SaleRecord.query.filter_by(sbis_order_id=order_id).first()
        is_new = sale is None

        if not sale:
            sale = SaleRecord(sbis_order_id=order_id)
            db.session.add(sale)

        sale.order_number = order_data.get('number', '')

        date_str = order_data.get('dateTime', order_data.get('date', ''))
        if date_str:
            try:
                sale.date = datetime.fromisoformat(date_str.replace('Z', '+00:00'))
            except:
                sale.date = None

        sale.point_id = str(order_data.get('pointId', self.point_id))
        sale.total_sum = float(order_data.get('sum', 0) or 0)
        sale.total_sum_with_vat = float(order_data.get('sumWithVat', sale.total_sum) or 0)
        sale.status = order_data.get('status', '')
        sale.items_json = order_data.get('items', order_data.get('products', []))
        sale.synced_at = datetime.utcnow()

        db.session.commit()
        return is_new

    def _recalculate_daily_sales(self):
        """Пересчёт дневных агрегатов"""
        from sqlalchemy import func, cast, Date

        logger.info("Пересчёт дневных агрегатов...")
        DailySalesSummary.query.delete()

        daily_data = db.session.query(
            cast(SaleRecord.date, Date).label('sale_date'),
            func.count(SaleRecord.id).label('orders'),
            func.sum(SaleRecord.total_sum).label('total'),
            func.sum(SaleRecord.total_sum_with_vat).label('total_vat')
        ).filter(SaleRecord.date != None).group_by('sale_date').all()

        for row in daily_data:
            summary = DailySalesSummary(
                date=row.sale_date,
                total_orders=row.orders or 0,
                total_sum=row.total or 0,
                total_sum_with_vat=row.total_vat or 0
            )
            db.session.add(summary)

        db.session.commit()
        logger.info("Агрегаты обновлены: %d дней", len(daily_data))

    # ==================== ОСТАТКИ ====================

    def sync_balances(self):
        """Синхронизация остатков"""
        logger.info("=" * 60)
        logger.info("СИНХРОНИЗАЦИЯ ОСТАТКОВ")
        logger.info("=" * 60)

        if not self.warehouse_id:
            logger.error("SBIS_WAREHOUSE_ID не настроен!")
            return 0

        balances_data = self.sbis.get_balances(
            warehouses=[self.warehouse_id],
            companies=[self.company_id] if self.company_id else None
        )

        if not balances_data:
            logger.error("Не удалось получить остатки")
            return 0

        StockBalance.query.delete()

        balances_list = balances_data.get('balances', []) if isinstance(balances_data, dict) else balances_data

        for bal_data in balances_list:
            name = bal_data.get('name', bal_data.get('Номенклатура', ''))

            balance = StockBalance(
                sbis_nomenclature_id=str(bal_data.get('id', '')),
                sbis_warehouse_id=str(bal_data.get('warehouseId', self.warehouse_id)),
                name=name,
                normalized_name=name.lower() if name else '',
                quantity=float(bal_data.get('quantity', bal_data.get('Количество', 0)) or 0),
                unit=bal_data.get('unit', bal_data.get('Единица', ''))
            )
            db.session.add(balance)

        db.session.commit()
        logger.info("Загружено %d остатков", len(balances_list))
        return len(balances_list)

    # ==================== НОМЕНКЛАТУРА ====================

    def sync_nomenclature(self):
        """Синхронизация номенклатуры"""
        logger.info("=" * 60)
        logger.info("СИНХРОНИЗАЦИЯ НОМЕНКЛАТУРЫ")
        logger.info("=" * 60)

        all_items = []
        page = 0

        while True:
            result = self.sbis.get_nomenclature_list(
                point_id=self.point_id,
                price_list_id=self.price_list_id,
                with_balance=True
            )

            if not result:
                break

            items = result.get('nomenclatures', result.get('items', []))
            if not items:
                break

            all_items.extend(items)
            logger.info("  Страница %d: %d товаров", page, len(items))

            if len(items) < 100:
                break

            page += 1
            import time
            time.sleep(0.2)

        logger.info("Всего получено %d товаров", len(all_items))

        # Сохраняем в JSON для справки (полноценная таблица — по запросу)
        with open('nomenclature_cache.json', 'w', encoding='utf-8') as f:
            json.dump(all_items, f, ensure_ascii=False, indent=2)

        logger.info("Сохранено в nomenclature_cache.json")
        return len(all_items)

    # ==================== СТАТИСТИКА ====================

    def get_stats(self):
        """Статистика по данным"""
        return {
            'sales_total': SaleRecord.query.count(),
            'sales_today': SaleRecord.query.filter(
                SaleRecord.date >= datetime.now().replace(hour=0, minute=0, second=0)
            ).count(),
            'sales_month': SaleRecord.query.filter(
                SaleRecord.date >= datetime.now().replace(day=1, hour=0, minute=0, second=0)
            ).count(),
            'balances_total': StockBalance.query.count(),
            'daily_summaries': DailySalesSummary.query.count()
        }


def main():
    parser = argparse.ArgumentParser(description='Синхронизация СБИС Retail API')
    parser.add_argument('--sales', action='store_true', help='Синхронизировать продажи')
    parser.add_argument('--balances', action='store_true', help='Синхронизировать остатки')
    parser.add_argument('--nomenclature', action='store_true', help='Синхронизировать номенклатуру')
    parser.add_argument('--all', action='store_true', help='Синхронизировать всё')
    parser.add_argument('--days', type=int, default=365, help='Период в днях (по умолчанию 365)')
    parser.add_argument('--stats', action='store_true', help='Показать статистику')

    args = parser.parse_args()

    sync = RetailSync()

    if args.stats:
        stats = sync.get_stats()
        print("\n" + "=" * 40)
        print("СТАТИСТИКА")
        print("=" * 40)
        for key, value in stats.items():
            print(f"  {key}: {value}")
        return

    if not any([args.sales, args.balances, args.nomenclature, args.all]):
        parser.print_help()
        return

    try:
        if args.sales or args.all:
            sync.sync_sales(args.days)

        if args.balances or args.all:
            sync.sync_balances()

        if args.nomenclature or args.all:
            sync.sync_nomenclature()

        # Итоговая статистика
        stats = sync.get_stats()
        print("\n" + "=" * 40)
        print("СИНХРОНИЗАЦИЯ ЗАВЕРШЕНА")
        print("=" * 40)
        for key, value in stats.items():
            print(f"  {key}: {value}")

    except Exception as e:
        logger.exception("Критическая ошибка")
        print(f"\n❌ Ошибка: {e}")
        sys.exit(1)


if __name__ == '__main__':
    main()
